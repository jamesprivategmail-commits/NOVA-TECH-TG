(() => {

const API = '/api';

let state = {
  token: localStorage.getItem('nova_token') || null,
  me: JSON.parse(localStorage.getItem('nova_me') || 'null'),
  conversations: [],
  activeConvId: null,
  activeConv: null,
  messages: {}, // convId -> [messages]
  socket: null,
  typingTimeout: null,
  myStatuses: [],
  pendingJoinCode: null,
  mediaRecorder: null,
  recordedChunks: [],
};

// Grab a join code from the URL if we landed on /join/CODE
(function detectJoinLink() {
  const m = location.pathname.match(/\/join\/([A-Za-z0-9]+)/);
  if (m) state.pendingJoinCode = m[1].toUpperCase();
})();

const $ = (sel) => document.querySelector(sel);
const $$ = (sel) => document.querySelectorAll(sel);

function api(path, opts = {}) {
  return fetch(API + path, {
    ...opts,
    headers: {
      'Content-Type': 'application/json',
      ...(state.token ? { Authorization: `Bearer ${state.token}` } : {}),
      ...(opts.headers || {})
    },
    body: opts.body ? JSON.stringify(opts.body) : undefined
  }).then(async (r) => {
    const data = await r.json().catch(() => ({}));
    if (!r.ok) throw new Error(data.error || 'Something went wrong');
    return data;
  });
}

function initials(name) {
  return (name || '?').trim().split(/\s+/).map(w => w[0]).slice(0, 2).join('').toUpperCase();
}

function timeAgo(dateStr) {
  const d = new Date(dateStr);
  const diff = (Date.now() - d.getTime()) / 1000;
  if (diff < 60) return 'now';
  if (diff < 3600) return `${Math.floor(diff / 60)}m`;
  if (diff < 86400) return `${Math.floor(diff / 3600)}h`;
  if (diff < 604800) return `${Math.floor(diff / 86400)}d`;
  return d.toLocaleDateString();
}

function clockTime(dateStr) {
  return new Date(dateStr).toLocaleTimeString([], { hour: 'numeric', minute: '2-digit' });
}

function escapeHtml(str) {
  const div = document.createElement('div');
  div.textContent = str ?? '';
  return div.innerHTML;
}

function verifiedBadge(isVerified) {
  return isVerified ? '<span class="verified-badge" title="Verified">✓</span>' : '';
}

// Renders an avatar div's background: image if avatarData present, else solid color
function styleAvatarEl(el, { avatarColor, avatarData }) {
  if (avatarData) {
    el.style.background = `url(${avatarData})`;
    el.style.backgroundSize = 'cover';
    el.style.backgroundPosition = 'center';
    el.textContent = '';
  } else {
    el.style.background = avatarColor || '#8E8E93';
  }
}

function fileToBase64(file) {
  return new Promise((resolve, reject) => {
    const r = new FileReader();
    r.onload = () => resolve(r.result.split(',')[1]);
    r.onerror = reject;
    r.readAsDataURL(file);
  });
}

function blobToBase64(blob) {
  return new Promise((resolve, reject) => {
    const r = new FileReader();
    r.onload = () => resolve(r.result.split(',')[1]);
    r.onerror = reject;
    r.readAsDataURL(blob);
  });
}

// ---------------- AUTH ----------------
const authScreen = $('#auth-screen');
const appScreen = $('#app-screen');

function showAuthError(msg) {
  const el = $('#auth-error');
  el.textContent = msg;
  el.classList.remove('hidden');
}
function hideAuthError() { $('#auth-error').classList.add('hidden'); }

$('#toggle-to-login a').addEventListener('click', (e) => {
  e.preventDefault();
  $('#signup-form').classList.add('hidden');
  $('#login-form').classList.remove('hidden');
  $('#toggle-to-login').classList.add('hidden');
  $('#toggle-to-signup').classList.remove('hidden');
  $('#auth-title').textContent = 'Welcome back';
  $('#auth-subtitle').textContent = 'Log in with your NOVA ID.';
  $('#nova-id-reveal').classList.add('hidden');
  hideAuthError();
});

$('#toggle-to-signup a').addEventListener('click', (e) => {
  e.preventDefault();
  $('#login-form').classList.add('hidden');
  $('#signup-form').classList.remove('hidden');
  $('#toggle-to-signup').classList.add('hidden');
  $('#toggle-to-login').classList.remove('hidden');
  $('#auth-title').textContent = 'Welcome to NOVA';
  $('#auth-subtitle').textContent = 'Message your people, your way.';
  hideAuthError();
});

$('#signup-form').addEventListener('submit', async (e) => {
  e.preventDefault();
  hideAuthError();
  const displayName = $('#signup-name').value.trim();
  const password = $('#signup-password').value;
  try {
    const { token, user } = await api('/auth/signup', { method: 'POST', body: { displayName, password } });
    $('#nova-id-reveal').classList.remove('hidden');
    $('#revealed-nova-id').textContent = user.novaId;
    setTimeout(() => login(token, user), 1800);
  } catch (err) {
    showAuthError(err.message);
  }
});

$('#login-form').addEventListener('submit', async (e) => {
  e.preventDefault();
  hideAuthError();
  const novaId = $('#login-novaid').value.trim();
  const password = $('#login-password').value;
  try {
    const { token, user } = await api('/auth/login', { method: 'POST', body: { novaId, password } });
    login(token, user);
  } catch (err) {
    showAuthError(err.message);
  }
});

function login(token, user) {
  state.token = token;
  state.me = user;
  localStorage.setItem('nova_token', token);
  localStorage.setItem('nova_me', JSON.stringify(user));
  boot();
}

function logout() {
  localStorage.removeItem('nova_token');
  localStorage.removeItem('nova_me');
  location.reload();
}

// ---------------- BOOT ----------------
async function boot() {
  authScreen.classList.add('hidden');
  appScreen.classList.remove('hidden');
  styleAvatarEl($('#me-avatar'), { avatarColor: state.me.avatarColor, avatarData: state.me.avatarData });
  if (!state.me.avatarData) $('#me-avatar').textContent = initials(state.me.displayName);
  $('#me-avatar').title = `${state.me.displayName} (${state.me.novaId}) — tap for your profile`;
  $('#me-avatar').addEventListener('click', () => openMyProfile());

  $('#admin-panel-btn').classList.toggle('hidden', !state.me.isAdmin);
  $('#admin-panel-btn').addEventListener('click', openAdminPanel);

  connectSocket();
  await loadConversations();
  initStatusColors();

  if (state.pendingJoinCode) {
    const code = state.pendingJoinCode;
    state.pendingJoinCode = null;
    try {
      const { conversation } = await api('/conversations/join', { method: 'POST', body: { inviteCode: code } });
      history.replaceState(null, '', '/');
      await loadConversations();
      openConversation(conversation.id);
    } catch (err) {
      alert(err.message);
    }
  }
}

function connectSocket() {
  state.socket = io({ auth: { token: state.token } });

  state.socket.on('connect_error', (err) => {
    if (/banned/i.test(err.message)) {
      alert('Your account has been banned.');
      logout();
    }
  });

  state.socket.on('message:new', (msg) => {
    if (!state.messages[msg.conversation_id]) state.messages[msg.conversation_id] = [];
    state.messages[msg.conversation_id].push(msg);
    if (state.activeConvId === msg.conversation_id) {
      renderMessages(msg.conversation_id);
    }
    loadConversations(); // refresh previews/order
  });

  state.socket.on('typing', ({ conversationId, userId, isTyping }) => {
    if (conversationId !== state.activeConvId || userId === state.me.id) return;
    const area = $('#messages-area');
    let indicator = document.getElementById('typing-indicator-el');
    if (isTyping) {
      if (!indicator) {
        indicator = document.createElement('div');
        indicator.id = 'typing-indicator-el';
        indicator.className = 'msg-row theirs';
        indicator.innerHTML = `<div class="typing-indicator"><span></span><span></span><span></span></div>`;
        area.appendChild(indicator);
        area.scrollTop = area.scrollHeight;
      }
    } else if (indicator) {
      indicator.remove();
    }
  });
}

// ---------------- TABS ----------------
$$('.tabbar button').forEach(btn => {
  btn.addEventListener('click', () => {
    $$('.tabbar button').forEach(b => b.classList.remove('active'));
    btn.classList.add('active');
    const tab = btn.dataset.tab;
    $('#tab-chats').classList.toggle('hidden', tab !== 'chats');
    $('#tab-status').classList.toggle('hidden', tab !== 'status');
    $('#tab-posts').classList.toggle('hidden', tab !== 'posts');
    if (tab === 'status') loadStatuses();
    if (tab === 'posts') loadPosts();
  });
});

// ---------------- CONVERSATIONS ----------------
async function loadConversations() {
  const { conversations } = await api('/conversations');
  state.conversations = conversations;
  renderConvList();
  if (state.activeConvId) {
    state.activeConv = state.conversations.find(c => c.id === state.activeConvId) || state.activeConv;
  }
}

function renderConvList() {
  const list = $('#conv-list');
  if (state.conversations.length === 0) {
    list.innerHTML = `<div class="empty-state"><div class="icon">👋</div><div class="title">No chats yet</div><div class="subtitle">Tap "+ New Chat" to message a friend.</div></div>`;
    return;
  }
  list.innerHTML = state.conversations.map(c => {
    const preview = c.last_message
      ? (c.last_sender_id === state.me.id ? 'You: ' : '') + escapeHtml(c.last_message)
      : (c.type === 'channel' ? 'No posts yet' : 'Say hi 👋');
    const badge = c.type === 'group' ? '<span class="conv-badge group">Group</span>'
      : c.type === 'channel' ? '<span class="conv-badge channel">Channel</span>' : '';
    const verified = c.type === 'dm' && c.other_user ? verifiedBadge(c.other_user.is_verified) : '';
    return `
      <div class="conv-item ${c.id === state.activeConvId ? 'active' : ''}" data-id="${c.id}">
        <div class="avatar" data-avatar-id="${c.id}">${initials(c.name || '?')}</div>
        <div class="conv-info">
          <div class="top-row">
            <span class="name">${escapeHtml(c.name || 'Unnamed')}${verified} ${badge}</span>
            <span class="time">${c.last_message_at ? timeAgo(c.last_message_at) : ''}</span>
          </div>
          <div class="preview">${preview}</div>
        </div>
      </div>`;
  }).join('');

  state.conversations.forEach(c => {
    const el = list.querySelector(`.avatar[data-avatar-id="${c.id}"]`);
    if (el) styleAvatarEl(el, { avatarColor: c.avatar_color });
  });

  $$('.conv-item').forEach(item => {
    item.addEventListener('click', () => openConversation(parseInt(item.dataset.id, 10)));
  });
}

async function openConversation(id) {
  state.activeConvId = id;
  appScreen.classList.add('chat-open');
  $('#chat-empty').classList.add('hidden');
  $('#chat-active').classList.remove('hidden');
  renderConvList();

  const conv = state.conversations.find(c => c.id === id);
  state.activeConv = conv;
  $('#chat-title').innerHTML = `${escapeHtml(conv?.name || 'Chat')}${conv?.type === 'dm' && conv?.other_user ? verifiedBadge(conv.other_user.is_verified) : ''}`;
  $('#chat-subtitle').textContent = conv?.type === 'channel' ? 'Channel' : conv?.type === 'group' ? 'Group' : conv?.other_user?.nova_id || '';
  styleAvatarEl($('#chat-avatar'), { avatarColor: conv?.avatar_color });
  $('#chat-avatar').textContent = conv?.avatar_data ? '' : initials(conv?.name || '?');

  // Show the manage (⋮) button only for groups/channels, not DMs
  $('#chat-manage-btn').classList.toggle('hidden', !conv || conv.type === 'dm');

  // Tapping a DM header opens that friend's profile
  $('#chat-header-info').onclick = () => {
    if (conv?.type === 'dm' && conv.other_user) viewProfileByNovaId(conv.other_user.nova_id);
  };

  state.socket.emit('conversation:join', { conversationId: id });

  if (!state.messages[id]) {
    const { messages } = await api(`/conversations/${id}/messages`);
    state.messages[id] = messages;
  }
  renderMessages(id);
}

$('#chat-back').addEventListener('click', () => {
  appScreen.classList.remove('chat-open');
});

function renderMediaContent(m) {
  if (m.media_type === 'image' && m.media_data) {
    return `<img class="msg-image" src="data:${m.media_mime};base64,${m.media_data}">`;
  }
  if (m.media_type === 'voice' && m.media_data) {
    return `<div class="msg-audio">🎙<audio controls src="data:${m.media_mime};base64,${m.media_data}"></audio></div>`;
  }
  return '';
}

function renderMessages(convId) {
  const area = $('#messages-area');
  const msgs = state.messages[convId] || [];
  let html = '';
  let lastSender = null;
  let lastTime = null;

  msgs.forEach((m, i) => {
    const mine = m.sender_id === state.me.id;
    const showTimeStamp = !lastTime || (new Date(m.created_at) - new Date(lastTime)) > 30 * 60 * 1000;

    if (showTimeStamp) {
      html += `<div class="msg-time">${new Date(m.created_at).toLocaleString([], { weekday: 'short', hour: 'numeric', minute: '2-digit' })}</div>`;
    }

    const isFirstInGroup = lastSender !== m.sender_id || showTimeStamp;
    if (isFirstInGroup && !mine) {
      html += `<div class="msg-group-sender">${escapeHtml(m.display_name)}${verifiedBadge(m.is_verified)}</div>`;
    }

    const mediaHtml = renderMediaContent(m);
    const textHtml = m.content ? escapeHtml(m.content) : '';

    html += `
      <div class="msg-row ${mine ? 'mine' : 'theirs'} ${isFirstInGroup ? 'grouped-first' : ''}">
        <div class="bubble ${mine ? 'mine' : 'theirs'}">${mediaHtml}${textHtml}</div>
      </div>`;

    lastSender = m.sender_id;
    lastTime = m.created_at;
  });

  area.innerHTML = html || `<div class="empty-state"><div class="icon">✨</div><div class="title">No messages yet</div><div class="subtitle">Say something!</div></div>`;
  area.scrollTop = area.scrollHeight;
}

// ---------------- COMPOSER ----------------
const composerInput = $('#composer-input');

composerInput.addEventListener('input', () => {
  composerInput.style.height = 'auto';
  composerInput.style.height = Math.min(composerInput.scrollHeight, 100) + 'px';
  $('#send-btn').disabled = !composerInput.value.trim();

  if (state.activeConvId) {
    state.socket.emit('typing', { conversationId: state.activeConvId, isTyping: true });
    clearTimeout(state.typingTimeout);
    state.typingTimeout = setTimeout(() => {
      state.socket.emit('typing', { conversationId: state.activeConvId, isTyping: false });
    }, 1500);
  }
});

composerInput.addEventListener('keydown', (e) => {
  if (e.key === 'Enter' && !e.shiftKey) {
    e.preventDefault();
    sendMessage();
  }
});

$('#send-btn').addEventListener('click', () => sendMessage());

function sendMessage(media) {
  const content = composerInput.value.trim();
  if (!content && !media || !state.activeConvId) {
    if (!state.activeConvId) return;
    if (!content && !media) return;
  }

  state.socket.emit('message:send', { conversationId: state.activeConvId, content, media }, (res) => {
    if (res?.error) alert(res.error);
  });

  composerInput.value = '';
  composerInput.style.height = 'auto';
  $('#send-btn').disabled = true;
  state.socket.emit('typing', { conversationId: state.activeConvId, isTyping: false });
}

// ---- image message ----
$('#image-btn').addEventListener('click', () => {
  if (!state.activeConvId) return alert('Open a chat first');
  $('#image-input').click();
});
$('#image-input').addEventListener('change', async (e) => {
  const file = e.target.files[0];
  if (!file) return;
  const data = await fileToBase64(file);
  sendMessage({ type: 'image', data, mime: file.type });
  e.target.value = '';
});

// ---- voice note message ----
$('#voice-btn').addEventListener('click', async () => {
  if (!state.activeConvId) return alert('Open a chat first');
  if (state.mediaRecorder && state.mediaRecorder.state === 'recording') {
    state.mediaRecorder.stop();
    return;
  }
  try {
    const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
    state.recordedChunks = [];
    const startedAt = Date.now();
    const recorder = new MediaRecorder(stream);
    state.mediaRecorder = recorder;
    recorder.ondataavailable = (e) => { if (e.data.size > 0) state.recordedChunks.push(e.data); };
    recorder.onstop = async () => {
      $('#voice-btn').classList.remove('recording');
      stream.getTracks().forEach(t => t.stop());
      const blob = new Blob(state.recordedChunks, { type: 'audio/webm' });
      const duration = Math.round((Date.now() - startedAt) / 1000);
      if (blob.size > 0) {
        const data = await blobToBase64(blob);
        sendMessage({ type: 'voice', data, mime: 'audio/webm', duration });
      }
    };
    recorder.start();
    $('#voice-btn').classList.add('recording');
  } catch (err) {
    alert('Microphone access is needed to record a voice note.');
  }
});

// ---------------- NEW CHAT MODAL ----------------
$('#new-chat-btn').addEventListener('click', () => $('#new-chat-modal').classList.remove('hidden'));
$('#close-new-chat').addEventListener('click', () => $('#new-chat-modal').classList.add('hidden'));

$$('.modal-tabs [data-newtab]').forEach(btn => {
  btn.addEventListener('click', () => {
    $$('.modal-tabs [data-newtab]').forEach(b => b.classList.remove('active'));
    btn.classList.add('active');
    ['dm', 'group', 'channel', 'join'].forEach(t => {
      document.getElementById(`newtab-${t}`).classList.toggle('hidden', t !== btn.dataset.newtab);
    });
    $('#modal-error').classList.add('hidden');
  });
});

function showModalError(msg) {
  const el = $('#modal-error');
  el.textContent = msg;
  el.classList.remove('hidden');
}

$('#dm-start-btn').addEventListener('click', async () => {
  try {
    const novaId = $('#dm-novaid').value.trim();
    const { conversationId } = await api('/conversations/dm', { method: 'POST', body: { novaId } });
    $('#new-chat-modal').classList.add('hidden');
    $('#dm-novaid').value = '';
    await loadConversations();
    openConversation(conversationId);
  } catch (err) { showModalError(err.message); }
});

$('#group-create-btn').addEventListener('click', async () => {
  try {
    const name = $('#group-name').value.trim();
    const memberNovaIds = $('#group-members').value.split(',').map(s => s.trim()).filter(Boolean);
    const { conversation } = await api('/conversations/group', { method: 'POST', body: { name, memberNovaIds } });
    $('#new-chat-modal').classList.add('hidden');
    $('#group-name').value = ''; $('#group-members').value = '';
    await loadConversations();
    openConversation(conversation.id);
  } catch (err) { showModalError(err.message); }
});

$('#channel-create-btn').addEventListener('click', async () => {
  try {
    const name = $('#channel-name').value.trim();
    const { conversation } = await api('/conversations/channel', { method: 'POST', body: { name } });
    $('#new-chat-modal').classList.add('hidden');
    $('#channel-name').value = '';
    await loadConversations();
    openConversation(conversation.id);
    setTimeout(() => openManageGroup(), 300); // show the NOVATECH link right away
  } catch (err) { showModalError(err.message); }
});

function extractInviteCode(input) {
  const trimmed = (input || '').trim();
  const m = trimmed.match(/\/join\/([A-Za-z0-9]+)/);
  return (m ? m[1] : trimmed).toUpperCase();
}

$('#join-btn').addEventListener('click', async () => {
  try {
    const inviteCode = extractInviteCode($('#join-code').value);
    const { conversation } = await api('/conversations/join', { method: 'POST', body: { inviteCode } });
    $('#new-chat-modal').classList.add('hidden');
    $('#join-code').value = '';
    await loadConversations();
    openConversation(conversation.id);
  } catch (err) { showModalError(err.message); }
});

// ---------------- MANAGE GROUP (add/remove members, rename, delete) ----------------
function showManageError(msg) {
  const el = $('#manage-group-error');
  el.textContent = msg;
  el.classList.remove('hidden');
}
function hideManageError() { $('#manage-group-error').classList.add('hidden'); }

$('#chat-manage-btn').addEventListener('click', openManageGroup);
$('#close-manage-group').addEventListener('click', () => $('#manage-group-modal').classList.add('hidden'));

async function openManageGroup() {
  hideManageError();
  const conv = state.activeConv;
  if (!conv) return;
  $('#manage-group-title').textContent = conv.name || 'Manage';
  $('#manage-group-name').value = conv.name || '';

  const isOwner = conv.owner_id === state.me.id;
  $('#manage-rename-group').classList.toggle('hidden', !isOwner);
  $('#manage-add-group').classList.toggle('hidden', conv.type !== 'group');
  $('#manage-delete-btn').classList.toggle('hidden', !isOwner);
  $('#manage-leave-btn').classList.toggle('hidden', isOwner);

  if (conv.invite_code) {
    $('#manage-invite-link-group').classList.remove('hidden');
    $('#manage-invite-link').value = `${location.origin}/join/${conv.invite_code}`;
  } else {
    $('#manage-invite-link-group').classList.add('hidden');
  }

  await renderManageMembers();
  $('#manage-group-modal').classList.remove('hidden');
}

$('#manage-copy-link-btn').addEventListener('click', () => {
  navigator.clipboard?.writeText($('#manage-invite-link').value);
  $('#manage-copy-link-btn').textContent = 'Copied!';
  setTimeout(() => { $('#manage-copy-link-btn').textContent = 'Copy'; }, 1500);
});

async function renderManageMembers() {
  const conv = state.activeConv;
  const { members } = await api(`/conversations/${conv.id}/members`);
  const myRole = members.find(m => m.id === state.me.id)?.role;
  const canModerate = ['owner', 'admin'].includes(myRole);

  const list = $('#manage-members-list');
  list.innerHTML = members.map(m => `
    <div class="conv-item" data-userid="${m.id}" style="cursor:default;">
      <div class="avatar sm profile-trigger" data-avatar-id="member-${m.id}" style="cursor:pointer;">${initials(m.display_name)}</div>
      <div class="conv-info profile-trigger" style="cursor:pointer;">
        <div class="top-row"><span class="name">${escapeHtml(m.display_name)}${verifiedBadge(m.is_verified)} ${m.role !== 'member' ? `<span class="conv-badge group">${m.role}</span>` : ''}</span></div>
        <div class="preview">${escapeHtml(m.nova_id)}</div>
      </div>
      ${canModerate && m.id !== state.me.id && m.role !== 'owner' ? `<button class="modal-close remove-member-btn" data-userid="${m.id}" style="position:static;">Remove</button>` : ''}
    </div>`).join('');

  members.forEach(m => {
    const el = list.querySelector(`.avatar[data-avatar-id="member-${m.id}"]`);
    if (el) styleAvatarEl(el, { avatarColor: m.avatar_color });
  });

  list.querySelectorAll('.profile-trigger').forEach(el => {
    el.addEventListener('click', () => {
      const userId = parseInt(el.closest('[data-userid]').dataset.userid, 10);
      const member = members.find(m => m.id === userId);
      if (member) viewProfileByNovaId(member.nova_id);
    });
  });

  list.querySelectorAll('.remove-member-btn').forEach(btn => {
    btn.addEventListener('click', async (e) => {
      e.stopPropagation();
      if (!confirm('Remove this person from the group?')) return;
      try {
        await api(`/conversations/${conv.id}/members/${btn.dataset.userid}`, { method: 'DELETE' });
        await renderManageMembers();
      } catch (err) { showManageError(err.message); }
    });
  });
}

$('#manage-add-btn').addEventListener('click', async () => {
  hideManageError();
  try {
    const novaId = $('#manage-add-novaid').value.trim();
    await api(`/conversations/${state.activeConv.id}/members`, { method: 'POST', body: { novaId } });
    $('#manage-add-novaid').value = '';
    await renderManageMembers();
  } catch (err) { showManageError(err.message); }
});

$('#manage-rename-btn').addEventListener('click', async () => {
  hideManageError();
  try {
    const name = $('#manage-group-name').value.trim();
    const { conversation } = await api(`/conversations/${state.activeConv.id}`, { method: 'PUT', body: { name } });
    $('#manage-group-title').textContent = conversation.name;
    $('#chat-title').textContent = conversation.name;
    await loadConversations();
  } catch (err) { showManageError(err.message); }
});

$('#manage-delete-btn').addEventListener('click', async () => {
  if (!confirm('Delete this group for everyone? This cannot be undone.')) return;
  try {
    await api(`/conversations/${state.activeConv.id}`, { method: 'DELETE' });
    $('#manage-group-modal').classList.add('hidden');
    appScreen.classList.remove('chat-open');
    $('#chat-active').classList.add('hidden');
    $('#chat-empty').classList.remove('hidden');
    state.activeConvId = null;
    state.activeConv = null;
    await loadConversations();
  } catch (err) { showManageError(err.message); }
});

$('#manage-leave-btn').addEventListener('click', async () => {
  if (!confirm('Leave this group?')) return;
  try {
    await api(`/conversations/${state.activeConv.id}/members/${state.me.id}`, { method: 'DELETE' });
    $('#manage-group-modal').classList.add('hidden');
    appScreen.classList.remove('chat-open');
    $('#chat-active').classList.add('hidden');
    $('#chat-empty').classList.remove('hidden');
    state.activeConvId = null;
    state.activeConv = null;
    await loadConversations();
  } catch (err) { showManageError(err.message); }
});

// ---------------- WHATSAPP-STYLE PROFILE PAGE ----------------
const profilePage = $('#profile-page');
$('#profile-back-btn').addEventListener('click', () => profilePage.classList.add('hidden'));

async function viewProfileByNovaId(novaId) {
  profilePage.classList.remove('hidden');
  $('#profile-name').textContent = 'Loading...';
  $('#profile-novaid').textContent = '';
  $('#profile-body').innerHTML = '';
  try {
    const { user } = await api(`/auth/lookup/${encodeURIComponent(novaId)}`);
    renderProfilePage(user, false);
  } catch (err) {
    $('#profile-name').textContent = "Couldn't load profile";
  }
}

function openMyProfile() {
  profilePage.classList.remove('hidden');
  renderProfilePage(state.me, true);
}

function renderProfilePage(user, isMe) {
  styleAvatarEl($('#profile-avatar'), { avatarColor: user.avatarColor, avatarData: user.avatarData });
  $('#profile-avatar').textContent = user.avatarData ? '' : initials(user.displayName);
  $('#profile-name').innerHTML = `${escapeHtml(user.displayName)}${verifiedBadge(user.isVerified)}`;
  $('#profile-novaid').textContent = user.novaId;

  const body = $('#profile-body');
  body.innerHTML = `
    <div class="profile-section">
      <div class="label">Bio</div>
      <div class="value" id="profile-bio-view">${user.bio ? escapeHtml(user.bio) : '<span style="color:var(--text-secondary)">No bio yet</span>'}</div>
    </div>
    <div class="profile-section">
      <div class="label">NOVA ID</div>
      <div class="value">${escapeHtml(user.novaId)}</div>
    </div>
    ${isMe ? `
    <div class="profile-section">
      <div class="label">Edit profile</div>
      <div class="field-group" style="margin-top:8px;">
        <label>Display name</label>
        <input type="text" id="edit-display-name" value="${escapeHtml(user.displayName)}" maxlength="60">
      </div>
      <div class="field-group">
        <label>Bio</label>
        <textarea id="edit-bio" rows="2" maxlength="160">${escapeHtml(user.bio || '')}</textarea>
      </div>
      <div class="field-group">
        <label>Profile photo</label>
        <input type="file" id="edit-avatar-input" accept="image/*">
      </div>
      <button class="btn-primary" id="save-profile-btn">Save changes</button>
    </div>
    <div class="profile-actions">
      <button class="icon-btn" id="copy-my-id-btn" style="width:auto; flex:1; border-radius:12px; padding:12px;">Copy my NOVA ID</button>
      <button class="btn-danger" id="profile-logout-btn" style="flex:1;">Log out</button>
    </div>` : ''}
  `;

  if (isMe) {
    $('#save-profile-btn').addEventListener('click', async () => {
      try {
        const displayName = $('#edit-display-name').value.trim();
        const bio = $('#edit-bio').value.trim();
        const fileInput = $('#edit-avatar-input');
        let avatarData, avatarMime;
        if (fileInput.files[0]) {
          avatarData = await fileToBase64(fileInput.files[0]);
          avatarMime = fileInput.files[0].type;
        }
        const { user: updated } = await api('/auth/me', { method: 'PUT', body: { displayName, bio, avatarData, avatarMime } });
        state.me = updated;
        localStorage.setItem('nova_me', JSON.stringify(updated));
        styleAvatarEl($('#me-avatar'), { avatarColor: updated.avatarColor, avatarData: updated.avatarData });
        renderProfilePage(updated, true);
        await loadConversations();
      } catch (err) { alert(err.message); }
    });
    $('#copy-my-id-btn').addEventListener('click', () => {
      navigator.clipboard?.writeText(user.novaId);
      alert('NOVA ID copied to clipboard.');
    });
    $('#profile-logout-btn').addEventListener('click', () => {
      if (confirm('Log out of NOVA?')) logout();
    });
  }
}

// ---------------- ADMIN PANEL ----------------
$('#close-admin-panel').addEventListener('click', () => $('#admin-modal').classList.add('hidden'));

function showAdminError(msg) {
  const el = $('#admin-error');
  el.textContent = msg;
  el.classList.remove('hidden');
}

async function openAdminPanel() {
  $('#admin-error').classList.add('hidden');
  $('#admin-modal').classList.remove('hidden');
  await loadAdminUsers();
}

let adminSearchTimeout = null;
$('#admin-search').addEventListener('input', () => {
  clearTimeout(adminSearchTimeout);
  adminSearchTimeout = setTimeout(() => loadAdminUsers($('#admin-search').value.trim()), 300);
});

async function loadAdminUsers(search = '') {
  try {
    const { users } = await api(`/admin/users${search ? `?search=${encodeURIComponent(search)}` : ''}`);
    renderAdminUsers(users);
  } catch (err) { showAdminError(err.message); }
}

function renderAdminUsers(users) {
  const list = $('#admin-users-list');
  if (users.length === 0) {
    list.innerHTML = `<div class="empty-state"><div class="subtitle">No users found</div></div>`;
    return;
  }
  list.innerHTML = users.map(u => `
    <div class="admin-user-row" data-userid="${u.id}">
      <div class="info">
        <div class="name">${escapeHtml(u.displayName)}</div>
        <div class="id">${escapeHtml(u.novaId)}</div>
      </div>
      <div class="tags">
        ${u.isBanned ? '<span class="admin-tag banned">Banned</span>' : ''}
        ${u.isVerified ? '<span class="admin-tag verified">Verified</span>' : ''}
      </div>
      <div class="admin-actions">
        ${u.isBanned
          ? `<button class="unban-btn">Unban</button>`
          : `<button class="ban-btn danger">Ban</button>`}
        ${u.isVerified
          ? `<button class="unverify-btn verify">Unverify</button>`
          : `<button class="verify-btn verify">Verify</button>`}
        <button class="delete-btn danger">Delete</button>
      </div>
    </div>`).join('');

  list.querySelectorAll('.admin-user-row').forEach(row => {
    const id = row.dataset.userid;
    row.querySelector('.ban-btn')?.addEventListener('click', async () => {
      const reason = prompt('Ban reason (optional):') || null;
      try { await api(`/admin/users/${id}/ban`, { method: 'POST', body: { reason } }); loadAdminUsers($('#admin-search').value.trim()); }
      catch (err) { showAdminError(err.message); }
    });
    row.querySelector('.unban-btn')?.addEventListener('click', async () => {
      try { await api(`/admin/users/${id}/unban`, { method: 'POST' }); loadAdminUsers($('#admin-search').value.trim()); }
      catch (err) { showAdminError(err.message); }
    });
    row.querySelector('.verify-btn')?.addEventListener('click', async () => {
      try { await api(`/admin/users/${id}/verify`, { method: 'POST' }); loadAdminUsers($('#admin-search').value.trim()); }
      catch (err) { showAdminError(err.message); }
    });
    row.querySelector('.unverify-btn')?.addEventListener('click', async () => {
      try { await api(`/admin/users/${id}/unverify`, { method: 'POST' }); loadAdminUsers($('#admin-search').value.trim()); }
      catch (err) { showAdminError(err.message); }
    });
    row.querySelector('.delete-btn')?.addEventListener('click', async () => {
      if (!confirm('Permanently delete this account? This cannot be undone.')) return;
      try { await api(`/admin/users/${id}`, { method: 'DELETE' }); loadAdminUsers($('#admin-search').value.trim()); }
      catch (err) { showAdminError(err.message); }
    });
  });
}

// ---------------- STATUS ----------------
const STATUS_COLORS = ['#7C5CFF', '#00D9C0', '#00C2FF', '#FFB020', '#FF4D6D', '#B9A6FF'];

function initStatusColors() {
  const wrap = $('#status-colors');
  wrap.innerHTML = STATUS_COLORS.map((c, i) =>
    `<button type="button" data-color="${c}" style="width:28px;height:28px;border-radius:50%;background:${c};border:${i === 0 ? '3px solid #fff' : 'none'}"></button>`
  ).join('');
  let selected = STATUS_COLORS[0];
  wrap.querySelectorAll('button').forEach(b => {
    b.addEventListener('click', () => {
      selected = b.dataset.color;
      wrap.querySelectorAll('button').forEach(x => x.style.border = 'none');
      b.style.border = '3px solid #fff';
    });
  });
  wrap.dataset.selected = selected;

  $('#status-post-btn').onclick = async () => {
    try {
      const content = $('#status-text').value.trim();
      if (!content) return showStatusError('Write something first');
      await api('/status', { method: 'POST', body: { content, bgColor: wrap.querySelector('button[style*="3px"]')?.dataset.color || selected } });
      $('#new-status-modal').classList.add('hidden');
      $('#status-text').value = '';
      loadStatuses();
    } catch (err) { showStatusError(err.message); }
  };
}

function showStatusError(msg) {
  const el = $('#status-error');
  el.textContent = msg;
  el.classList.remove('hidden');
}

$('#close-new-status').addEventListener('click', () => $('#new-status-modal').classList.add('hidden'));

async function loadStatuses() {
  const { statuses } = await api('/status/feed');
  const list = $('#status-list');
  const mine = statuses.filter(s => s.user_id === state.me.id);
  const others = statuses.filter(s => s.user_id !== state.me.id);
  state.myStatuses = mine;

  let html = `
    <div class="status-item" id="add-status-row">
      <div class="status-ring">
        <div class="avatar sm" style="background:${state.me.avatarColor}">${mine.length ? initials(state.me.displayName) : '+'}</div>
      </div>
      <div>
        <div style="font-weight:700;">My Status</div>
        <div style="font-size:12px;color:var(--text-secondary);">${mine.length ? `${mine.length} active — tap to view` : 'Tap to add status update'}</div>
      </div>
      <button class="modal-close" id="add-status-plus-btn" style="position:static; margin-left:auto;">+</button>
    </div>`;

  if (others.length === 0) {
    html += `<div class="empty-state"><div class="icon">🌟</div><div class="title">No updates yet</div><div class="subtitle">When friends post a status, it'll show up here.</div></div>`;
  } else {
    html += others.map(s => `
      <div class="status-item" data-id="${s.id}">
        <div class="status-ring ${s.viewed ? 'viewed' : ''}">
          <div class="avatar sm" style="background:${s.avatar_color}">${initials(s.display_name)}</div>
        </div>
        <div>
          <div style="font-weight:700;">${escapeHtml(s.display_name)}${verifiedBadge(s.is_verified)}</div>
          <div style="font-size:12px;color:var(--text-secondary);">${timeAgo(s.created_at)} ago</div>
        </div>
      </div>`).join('');
  }

  list.innerHTML = html;

  $('#add-status-row').addEventListener('click', (e) => {
    if (e.target.id === 'add-status-plus-btn') return;
    if (mine.length > 0) {
      viewStatus(mine[0], true);
    } else {
      $('#new-status-modal').classList.remove('hidden');
    }
  });

  $('#add-status-plus-btn').addEventListener('click', (e) => {
    e.stopPropagation();
    $('#new-status-modal').classList.remove('hidden');
  });

  list.querySelectorAll('.status-item[data-id]').forEach(item => {
    item.addEventListener('click', () => viewStatus(others.find(s => s.id == item.dataset.id)));
  });
}

async function viewStatus(status, isMine) {
  if (!status) return;
  if (!isMine) await api(`/status/${status.id}/view`, { method: 'POST' });

  const backdrop = $('#status-viewer');
  backdrop.innerHTML = `
    <div class="status-viewer-card" style="background:${status.bg_color}">
      <div class="status-viewer-progress"><div class="status-viewer-progress-fill"></div></div>
      <div class="status-viewer-header">
        <div class="avatar sm" style="background:rgba(0,0,0,0.2)">${initials(status.display_name)}</div>
        <span>${escapeHtml(status.display_name)}${isMine ? ' (you)' : ''}</span>
      </div>
      <button class="status-viewer-close" id="status-viewer-close">✕</button>
      <div>${escapeHtml(status.content)}</div>
    </div>`;
  backdrop.classList.remove('hidden');

  const close = () => backdrop.classList.add('hidden');
  $('#status-viewer-close').addEventListener('click', close);
  backdrop.addEventListener('click', (e) => { if (e.target === backdrop) close(); });
  setTimeout(close, 5000);
}

// ---------------- POSTS ----------------
let pendingPostImage = null;

$('#post-image-btn').addEventListener('click', () => $('#post-image-input').click());
$('#post-image-input').addEventListener('change', async (e) => {
  const file = e.target.files[0];
  if (!file) return;
  pendingPostImage = { data: await fileToBase64(file), mime: file.type };
  const preview = $('#post-image-preview');
  preview.src = `data:${file.type};base64,${pendingPostImage.data}`;
  preview.style.display = 'block';
});

$('#new-post-btn').addEventListener('click', async () => {
  const caption = $('#new-post-text').value.trim();
  if (!caption && !pendingPostImage) return;
  try {
    await api('/posts', { method: 'POST', body: { caption, imageData: pendingPostImage?.data, imageMime: pendingPostImage?.mime } });
    $('#new-post-text').value = '';
    pendingPostImage = null;
    $('#post-image-preview').style.display = 'none';
    $('#post-image-input').value = '';
    loadPosts();
  } catch (err) { alert(err.message); }
});

async function loadPosts() {
  const { posts } = await api('/posts');
  const list = $('#posts-list');
  if (posts.length === 0) {
    list.innerHTML = `<div class="empty-state"><div class="icon">📸</div><div class="title">No posts yet</div><div class="subtitle">Be the first to share something.</div></div>`;
    return;
  }
  list.innerHTML = posts.map(p => `
    <div class="post-card" data-id="${p.id}">
      <div class="post-header">
        <div class="avatar sm" style="background:${p.avatar_color}">${initials(p.display_name)}</div>
        <div>
          <div style="font-weight:700;">${escapeHtml(p.display_name)}${verifiedBadge(p.is_verified)}</div>
          <div style="font-size:12px;color:var(--text-secondary);">${timeAgo(p.created_at)} ago</div>
        </div>
        ${p.user_id === state.me.id ? `<button class="post-delete-btn" style="background:none;border:none;font-weight:700;font-size:12px;">Delete</button>` : ''}
      </div>
      ${p.caption ? `<div class="post-caption">${escapeHtml(p.caption)}</div>` : ''}
      ${p.image_data ? `<img class="post-image" src="data:${p.image_mime};base64,${p.image_data}">` : ''}
      <div class="post-actions">
        <button class="like-btn ${p.liked_by_me ? 'liked' : ''}">♥ <span class="like-count">${p.like_count}</span></button>
        <button class="comment-toggle-btn">💬 <span class="comment-count">${p.comment_count}</span></button>
      </div>
      <div class="post-comments hidden"></div>
    </div>`).join('');

  list.querySelectorAll('.post-card').forEach(card => {
    const postId = card.dataset.id;

    card.querySelector('.like-btn').addEventListener('click', async () => {
      try {
        const { liked } = await api(`/posts/${postId}/like`, { method: 'POST' });
        const btn = card.querySelector('.like-btn');
        const countEl = btn.querySelector('.like-count');
        countEl.textContent = parseInt(countEl.textContent, 10) + (liked ? 1 : -1);
        btn.classList.toggle('liked', liked);
      } catch (err) { alert(err.message); }
    });

    card.querySelector('.comment-toggle-btn').addEventListener('click', async () => {
      const box = card.querySelector('.post-comments');
      if (!box.classList.contains('hidden')) { box.classList.add('hidden'); return; }
      box.classList.remove('hidden');
      const { comments } = await api(`/posts/${postId}/comments`);
      box.innerHTML = comments.map(c => `<div class="post-comment-row"><b>${escapeHtml(c.display_name)}${verifiedBadge(c.is_verified)}:</b> ${escapeHtml(c.content)}</div>`).join('')
        + `<div class="post-comment-input"><input type="text" placeholder="Add a comment..." class="new-comment-input"><button class="modal-close send-comment-btn" style="position:static;">Send</button></div>`;
      box.querySelector('.send-comment-btn').addEventListener('click', async () => {
        const input = box.querySelector('.new-comment-input');
        const content = input.value.trim();
        if (!content) return;
        try {
          await api(`/posts/${postId}/comments`, { method: 'POST', body: { content } });
          input.value = '';
          const countEl = card.querySelector('.comment-count');
          countEl.textContent = parseInt(countEl.textContent, 10) + 1;
          const { comments: refreshed } = await api(`/posts/${postId}/comments`);
          box.querySelectorAll('.post-comment-row').forEach(r => r.remove());
          box.insertAdjacentHTML('afterbegin', refreshed.map(c => `<div class="post-comment-row"><b>${escapeHtml(c.display_name)}${verifiedBadge(c.is_verified)}:</b> ${escapeHtml(c.content)}</div>`).join(''));
        } catch (err) { alert(err.message); }
      });
    });

    card.querySelector('.post-delete-btn')?.addEventListener('click', async () => {
      if (!confirm('Delete this post?')) return;
      try { await api(`/posts/${postId}`, { method: 'DELETE' }); loadPosts(); }
      catch (err) { alert(err.message); }
    });
  });
}

// ---------------- INIT ----------------
if (state.token && state.me) {
  boot();
}

// ---------------- PWA SERVICE WORKER ----------------
if ('serviceWorker' in navigator) {
  navigator.serviceWorker.register('/sw.js').catch(err => {
    console.warn('Service worker registration failed:', err);
  });
}

})();
